package com.example.class4api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Class4ApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
